create view user_information as
select `e`.`id`                                         AS `id`,
       concat(`e`.`first_name`, ' ', `e`.`last_name`)   AS `Name`,
       `e`.`birth_date`                                 AS `Birth`,
       `e`.`e-mail`                                     AS `E-mail`,
       `e`.`phone_number`                               AS `Phone`,
       `de`.`name_deparment`                            AS `Department`,
       group_concat(distinct `pr`.`name` separator ',') AS `Projects`,
       concat(`m`.`first_name`, ' ', `m`.`last_name`)   AS `Manager`
from ((((((`holidaydb`.`employee` `e` left join `holidaydb`.`department_has_employees` `dhe` on ((`dhe`.`employee_id` = `e`.`id`))) left join `holidaydb`.`department` `de` on ((`de`.`id` = `dhe`.`department_id`))) left join `holidaydb`.`employee_has_project` `ehp` on ((`ehp`.`employee_id` = `e`.`id`))) left join `holidaydb`.`project` `pr` on ((`pr`.`id` = `ehp`.`project_id`))) left join `holidaydb`.`manager_has_employee` `mhe` on ((`mhe`.`employee_id` = `e`.`id`)))
         left join `holidaydb`.`employee` `m` on ((`mhe`.`manager_id` = `m`.`id`)))
group by `e`.`id`;

