create definer = root@localhost view project_information as
select `pr`.`id`                                                                           AS `id`,
       `pr`.`name`                                                                         AS `Name`,
       `pr`.`description`                                                                  AS `Description`,
       `pr`.`deadline`                                                                     AS `Deadline`,
       group_concat(distinct concat(`e`.`first_name`, ' ', `e`.`last_name`) separator ',') AS `Employees`
from ((`holidaydb`.`employee` `e` join `holidaydb`.`employee_has_project` `ehp` on ((`ehp`.`employee_id` = `e`.`id`)))
         left join `holidaydb`.`project` `pr` on ((`pr`.`id` = `ehp`.`project_id`)))
group by `pr`.`id`;

