create definer = root@localhost view department_information as
select `de`.`id`                                                                           AS `id`,
       `de`.`name_deparment`                                                               AS `Name`,
       group_concat(distinct concat(`e`.`first_name`, ' ', `e`.`last_name`) separator ',') AS `Employees`,
       concat(`m`.`first_name`, ' ', `m`.`last_name`)                                      AS `Manager`
from ((((`holidaydb`.`employee` `e` join `holidaydb`.`department_has_employees` `dhe` on ((`dhe`.`employee_id` = `e`.`id`))) join `holidaydb`.`department` `de` on ((`de`.`id` = `dhe`.`department_id`))) join `holidaydb`.`manager_has_employee` `mhe` on ((`mhe`.`employee_id` = `e`.`id`)))
         join `holidaydb`.`employee` `m` on ((`mhe`.`manager_id` = `m`.`id`)))
group by `de`.`id`;

