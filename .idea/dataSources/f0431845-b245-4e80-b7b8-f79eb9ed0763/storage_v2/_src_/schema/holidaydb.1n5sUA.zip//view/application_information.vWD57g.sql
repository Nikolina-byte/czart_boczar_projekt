create view application_information as
select `a`.`id`                                         AS `Id`,
       `e`.`id`                                         AS `Id_employee`,
       `a`.`type_leave`                                 AS `LeaveType`,
       `a`.`start_date`                                 AS `StartDay`,
       `a`.`end_date`                                   AS `EndDay`,
       (`a`.`end_date` - `a`.`start_date`)              AS `NumberDay`,
       `a`.`status`                                     AS `Status`,
       concat(`e`.`first_name`, ' ', `e`.`last_name`)   AS `Name`,
       `de`.`name_deparment`                            AS `Department`,
       group_concat(distinct `pr`.`name` separator ',') AS `Projects`
from (((((`holidaydb`.`application` `a` join `holidaydb`.`employee` `e` on ((`e`.`id` = `a`.`employee_id`))) left join `holidaydb`.`department_has_employees` `dhe` on ((`dhe`.`employee_id` = `e`.`id`))) left join `holidaydb`.`department` `de` on ((`de`.`id` = `dhe`.`department_id`))) left join `holidaydb`.`employee_has_project` `ehp` on ((`ehp`.`employee_id` = `e`.`id`)))
         left join `holidaydb`.`project` `pr` on ((`pr`.`id` = `ehp`.`project_id`)))
group by `a`.`id`;

